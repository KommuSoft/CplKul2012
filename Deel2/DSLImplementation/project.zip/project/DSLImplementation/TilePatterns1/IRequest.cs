using System;

namespace DSLImplementation.IntermediateCode {

	public interface IRequest {

		IAnswer execute ();

	}
}

