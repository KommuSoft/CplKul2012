using System;

namespace DSLImplementation.Tiling {

	[AttributeUsage(AttributeTargets.Class)]
	public class TilePatternAttribute : Attribute {

		public TilePatternAttribute ()
		{
		}

	}
}

