using System;

namespace DSLImplementation.IntermediateCode {

	public abstract class XmlRequestBase : IRequest {

		public abstract IAnswer execute ();

	}
}

