using System;

namespace DSLImplementation.Database
{
	public interface ILocatable
	{
	}
}

