using System;

namespace DSLImplementation.UserInterface {

	public interface ILocationPiece : IPuzzlePiece {
	}

}