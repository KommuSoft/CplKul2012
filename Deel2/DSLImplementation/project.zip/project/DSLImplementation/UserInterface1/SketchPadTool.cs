using System;

namespace DSLImplementation.UserInterface {

	public enum SketchPadTool {
		CreateNew,
		Link,
		Modify,
		Remove
	}

}