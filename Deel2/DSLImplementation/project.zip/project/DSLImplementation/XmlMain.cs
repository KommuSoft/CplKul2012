using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DSLImplementation.IntermediateCode{
	public class XmlMain{

		public static void Main (string[] args){
		}
	}
}

