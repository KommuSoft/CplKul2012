using System;
namespace DSLImplementation.IntermediateCode
{
	public class SeatClass
	{
		public SeatClass(String Name){
			this.Name = Name;
		}

		public String Name { get; set; }
	}
}

