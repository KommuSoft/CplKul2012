namespace DSLImplementation.IntermediateCode {

	public interface ILocation {

	}
}

