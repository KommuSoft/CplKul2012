using System;
namespace DSLImplementation.IntermediateCode
{
	public class Passenger
	{		
		public Passenger (String Name){
			this.Name = Name;
		}

		public String Name { get; set; }
	}
}

